package dev.selenium;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.devtools.v118.v118CdpInfo;
import org.openqa.selenium.support.ui.Select;

public class ChromeTest {

   static ChromeDriver driver;

   @BeforeAll
   public static void before() {
      ChromeOptions options = new ChromeOptions();
      options.addArguments("start-maximized");
      driver = new ChromeDriver(options);

      driver.get("file:/Users/efrencorzonvazquez/Desktop/CD_UD3_Selenium_maven/src/index.html");
      try {
         Thread.sleep(2000);
      } catch (InterruptedException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }

   }

   // 1. Enviar el formulario completando el user y la password únicamente.
   @Test
   public void test1() {

      // Buscamos los elementos.
      WebElement inputUser = driver.findElement(By.id("inputUser"));
      WebElement inputPass = driver.findElement(By.id("inputPass"));
      WebElement searchButton = driver.findElement(By.className("btn-primary"));

      inputUser.sendKeys("efren");
      inputPass.sendKeys("abc123.");
      // Duerme 2 seg(Theread siempre va dentro de un try/catch)
      try {
         Thread.sleep(2000);
      } catch (InterruptedException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
      searchButton.click();

      // assertEquals(h1 , "Formulario procesado");
      // Primero buscamos el elemento(tiene que ser de forma secuencial).
      WebElement h1 = driver.findElement(By.tagName("h1"));

      // Segundo comparamos el elemento con el texto de dicho elemento.
      assertEquals("Formulario procesado", h1.getText());
   }

   // 2. Hacer click en "Check me out" y hacer click en "Confirm".
   @Test
   public void test2() {
      WebElement inputCheck = driver.findElement(By.className("form-check-input"));
      WebElement searchButton = driver.findElement(By.className("btn-primary"));

      try {
         Thread.sleep(2000);
      } catch (InterruptedException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }

      inputCheck.click();
      searchButton.click();

   }

   // 3. Seleccionar del select la opción "Dos" con el index.
   @Test
   public void test3() {
      Select comboboxSimple = new Select(driver.findElement(By.className("form-select")));

      comboboxSimple.selectByIndex(2);

      try {
         Thread.sleep(2000);
      } catch (InterruptedException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }

      WebElement searchButton = driver.findElement(By.className("btn-primary"));
      searchButton.click();
   }

   // 4. Seleccionar del select la opción "uno" por el nombre.
   @Test
   public void test4() {
      Select comboboxSimple = new Select(driver.findElement(By.className("form-select")));
      comboboxSimple.selectByValue("2");
      try {
         Thread.sleep(2000);
      } catch (InterruptedException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }

      WebElement searchButton = driver.findElement(By.className("btn-primary"));
      searchButton.click();

   }

   @AfterAll
   public static void after() {
      driver.quit();

   }
}
